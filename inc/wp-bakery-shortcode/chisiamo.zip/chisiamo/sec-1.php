<?php



add_action('vc_before_init', 'redp_chismo_sec_1_backend');


function redp_chismo_sec_1_backend()

{

    vc_map(

        array(

            "name" => __("Main slider", "redapple"),
            "base" => "redp_chismo_sec_1",
            'icon' => get_template_directory_uri() . '/assets/images/logo-dark.png',
            'description' => 'Dedicated for redapple',
            "class" => "redapple-cstm",
            "category" => __('Chi Siamo', 'redapple'),
            'params' => array(
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Title ", "redapple"),
                    "param_name" => "chsm_2_title",
                    "value" => __("", "redapple"),
                ),
            )
        )
    );
}

add_shortcode('redp_chismo_sec_1', 'redp_chismo_sec_1_view');

function redp_chismo_sec_1_view($atts)

{

    ob_start();

    $atts = shortcode_atts(array(
        'chsm_2_title' => '',
        // 'chsm_2_logos' => '',
    ), $atts, 'redp_chismo_sec_1');

    $chsm_2_title = $atts['chsm_2_title'] ?? '';
    // $chsm_2_logo_ids = $atts['chsm_2_logos'] ?? '';
    // $chsm_2_logo_ids_url = wp_get_attachment_image_url($chsm_2_logo_ids);
    // $items = vc_param_group_parse_atts($atts['octgn_hm_sec_1_sliders_items']);
    // $all_logo_ids = explode(",", $chsm_2_logo_ids);
    // $logo_id_count = count($all_logo_ids);

?>

    <!-- home slider start from here  -->
    <section class="home-slider-main">

        <div class="swiper home-slider">

            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="slide-bg" style="background: url(<?php echo get_template_directory_uri();?>/assets/images/chisiamo/chisiamo.png);"> </div>
                    <div class="slider-cotentbox">
                        <h2>pensare oltre </h2>
                    </div>

                </div>
                <div class="swiper-slide">
                    <div class="slide-bg" style="background: url(<?php echo get_template_directory_uri();?>/assets/images/home/slider1.png);"> </div>
                    <div class="slider-cotentbox">
                        <h2>CONTROTELAI E SISTEMI <br>
                            PER PORTE E FINESTRE SCORREVOLI
                        </h2>
                    </div>

                </div>
                <div class="swiper-slide video-slide" data-swiper-autoplay="">
                    <div class="video-bg">
                        <video autoplay muted loop class="swiper-video">
                            <source src="<?php echo get_template_directory_uri();?>/assets/images/home/video.mp4" type="video/mp4">
                        </video>
                        <div class="slider-cotentbox">
                            <h2>CONTROTELAI E SISTEMI <br>
                                PER PORTE E FINESTRE SCORREVOLI
                            </h2>
                        </div>
                    </div>

                </div>

            </div>

            <!-- <div class="swiper-pagination"></div> -->

            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>


        </div>
    </section>
    <!-- home slider ends here  -->

    <!-- chisiamo description start from here  -->
    <section class="chisiamo-description-main">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <h3>Il mondo cambia, evolve e si trasforma oltre ogni nostra immaginazione, <br>
                        anche a seguito di eventi e situazioni mai ipotizzate sinora.</h3>

                    <p>Protek® si propone di pensare, prevedere e gestire questi nuovi scenari sociali ed è per
                        questo che, interpretando questa continua evoluzione, <br> Protek® ha pensato ad elementi
                        che
                        permettono di utilizzare al meglio gli spazi abitativi, in grado di trasformarli a seconda
                        delle esigenze e dei <br> cambiamenti talvolta repentini del modo di vivere.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- chisiamo description end here  -->

    <!-- chisiamo counter start from here  -->

    <section class="chisiamo-counter-main">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="counter-title">
                        <h3>Storia, esperienza, manifattura, proprietà. </h3>
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-xs-12 col-sm-12 col-md-3 col-lg-2">
                    <div class="single-coutnerup">
                        <span class="count-num">22</span>
                        <h4 class="title">anni di esperienza</h4>

                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-1 col-lg-1 d-none d-lg-block"></div>
                <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                    <div class="single-coutnerup">
                        <span class="count-num">10.000</span>
                        <span class="counter-text">mq</span>
                        <h4 class="title">produzione</h4>

                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                    <div class="single-coutnerup">
                        <span class="count-num">5.000.000</span>
                        <h4 class="title">articoli venduti.</h4>

                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-1 col-lg-1 d-none d-lg-block"></div>
                <div class="col-xs-12 col-sm-12 col-md-3 col-lg-2">
                    <div class="single-coutnerup">
                        <span class="count-num">25</span>
                        <h4 class="title">brevetti</h4>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- chisiamo counter end here  -->

    <!-- chisiamo noi section start from here  -->
    <section class="chisiamo-noi-main">
        <div class="container">
            <div class="row">

                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="noi-imagebox">
                        <img src="<?php echo get_template_directory_uri();?>/assets/images/chisiamo/noi.png" alt="noi.png">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="noi-contentbox">
                        <div class="noi-titlebox">
                            <h3>NOI </h3>
                        </div>
                        <div class="description">
                            <p>Protek® è il racconto di una storia familiare, di persone determinate e di un forte
                                legame con il territorio.</p>
                            <p>I fratelli Giovanni e Maurizio Maggioni, a metà degli Anni ‘80, raccolgono l’eredità
                                di esperienze e le redini dell’attività artigianale del papà Rino, fondata nel 1951:
                                una piccola officina meccanica, operante nel cuore della Brianza. <br>
                                Intraprendenza e dedizione sono state e sono le caratteristiche che hanno consentito
                                loro di sviluppare negli anni numerosi progetti, rivolti ai più differenti settori
                                dell’industria e dell’artigianato.</p>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </section>
    <!-- chisiamo noi section ends here  -->

    <!-- breveti section start from here  -->

    <section class="breveti-main">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                    <div class="title-box">
                        <h3>i nostri brevetti</h3>
                    </div>
                </div>
            </div>
            <div class="row justify-content-between">
                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                    <div class="single-brevetti">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                <div class="brevatti-imagebox">
                                    <img src="<?php echo get_template_directory_uri();?>/assets/images/chisiamo/1.png" alt="">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                <div class="brevetti-desc">
                                    <p>Linear®: la serie di porte battenti e controtelai per porte scorrevoli
                                        concepita per eliminare l’utilizzo di stipiti e coprifili.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                    <div class="single-brevetti">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                <div class="brevatti-imagebox">
                                    <img src="<?php echo get_template_directory_uri();?>/assets/images/chisiamo/2.png" alt="">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                <div class="brevetti-desc">
                                    <p>Magic Box®: la serie di controtelai ideati e brevettati da Protek®
                                        predisposti per le utenze elettriche e/o idriche.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                    <div class="single-brevetti">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                <div class="brevatti-imagebox">
                                    <img src="<?php echo get_template_directory_uri();?>/assets/images/chisiamo/3.png" alt="">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                <div class="brevetti-desc">
                                    <p>
                                        Bigfoot® è il sistema brevettato di Protek® che trasforma lo spazio
                                        generando soluzioni innovative per il progetto architettonico e d’interni.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                    <div class="single-brevetti">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                <div class="brevatti-imagebox">
                                    <img src="<?php echo get_template_directory_uri();?>/assets/images/chisiamo/4.png" alt="">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                <div class="brevetti-desc">
                                    <p>Lifty system®: il sistema progettato e brevettato da Protek® che consente una
                                        regolazione ed un montaggio della porta più rapido rispetto ad un sistema
                                        tradizionale.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                    <div class="single-brevetti">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                <div class="brevatti-imagebox">
                                    <img src="<?php echo get_template_directory_uri();?>/assets/images/chisiamo/5.png" alt="">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                <div class="brevetti-desc">
                                    <p>
                                        Protek® ha pensato ad elementi che permettono di utilizzare al meglio gli
                                        spazi abitativi, in grado di trasformarli a seconda delle esigenze e dei
                                        cambiamenti talvolta repentini del modo di vivere.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                    <div class="single-brevetti">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                <div class="brevatti-imagebox">
                                    <img src="<?php echo get_template_directory_uri();?>/assets/images/chisiamo/6.png" alt="">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                <div class="brevetti-desc">
                                    <p>Skudo®: il controtelaio in kit per pareti in cartongesso, facile da
                                        trasportare grazie alle sue dimensioni ridotte.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- breveti section start from here  -->

    <!-- chisiamo-sostenibilità starts from here  -->

    <section class="home-portek-main chisiamo-sostenibilità-main">
        <div class="container">
            <div class="row">
                <di v class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                    <div class="home-common-title">
                        <h2> sostenibilità</h2>
                    </div>
                    <div class="about-protek">
                        <p>
                            L'attenzione alla sostenibilità ed il rispetto dell'ambiente sono da sempre valori
                            importanti per Protek® che ne ha fatto un proprio caposaldo di gestione d'impresa.
                            Abbiamo concretamente attuato una serie di processi di sviluppo sostenibile, industriale
                            e di servizio, che rispecchiano a pieno la nostra filosofia aziendale, tra cui il
                            riconoscimento delle certificazioni ISO 9001 e ISO 14001.
                            Il legno dei nostri controtelai è certificato FSC e PEFC ossia proveniente da foreste
                            gestite in maniera responsabile a tutela dell'ambiente.
                            Sia il controtelaio che il packaging sono 100% riciclabili e sono realizzati in maniera
                            tale da garantire completamente la salvaguardia ambientale.
                        </p>


                    </div>
                </di>
                <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2 d-none d-md-block d-lg-block"></div>
                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                    <div class="protek-images">
                        <img src="<?php echo get_template_directory_uri();?>/assets/images/chisiamo/sost.png" alt="sost.png">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- chisiamo-sostenibilità ends here  -->

    <!-- storia section start from here  -->
    <section class="storia-main">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ">
                    <div class="title-box">
                        <h3>La nostra storia</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="swiper year-slider">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="year-contents">
                                    <div class="year">2005</div>
                                    <div class="contents">
                                        Viene brevettato il controtelaio <br> MAGIC BOX® la linea con le <br>
                                        predisposizioni
                                        per impianti
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="year-contents">
                                    <div class="year">2006</div>
                                    <div class="contents">
                                        Viene brevettato il controtelaio <br> SKUDO®
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="year-contents">
                                    <div class="year">2007</div>
                                    <div class="contents">
                                        Nasce la serie LINEAR®: <br> controtelai per porte scorrevoli <br> senza
                                        stipiti e
                                        coprifi li.
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="year-contents">
                                    <div class="year">2008-09</div>
                                    <div class="contents">

                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="year-contents">
                                    <div class="year">2005</div>
                                    <div class="contents">
                                        Viene brevettato il controtelaio <br> MAGIC BOX® la linea con le <br>
                                        predisposizioni
                                        per impianti
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="year-contents">
                                    <div class="year">2006</div>
                                    <div class="contents">
                                        Viene brevettato il controtelaio <br> SKUDO®
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="year-contents">
                                    <div class="year">2007</div>
                                    <div class="contents">
                                        Nasce la serie LINEAR®: <br> controtelai per porte scorrevoli <br> senza
                                        stipiti e
                                        coprifi li.
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="year-contents">
                                    <div class="year">2008-09</div>
                                    <div class="contents">

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-button-prev"></div>
                        <div class="swiper-button-next"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- storia section ends here  -->

    <!-- chisiamo certifacte section start from here  -->
    <section class="chisiamo-certifacate-main">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                    <div class="certifica-iamgebox">
                        <div class="certifica-grid">
                            <div class="single-grid">
                                <img src="<?php echo get_template_directory_uri();?>/assets/images/accessori/c1.png" alt="">
                            </div>
                            <div class="single-grid">
                                <img src="<?php echo get_template_directory_uri();?>/assets/images/accessori/c2.png" alt="">
                            </div>
                            <div class="single-grid">
                                <img src="<?php echo get_template_directory_uri();?>/assets/images/accessori/c3.png" alt="">
                            </div>
                            <div class="single-grid">
                                <img src="<?php echo get_template_directory_uri();?>/assets/images/accessori/c4.png" alt="">
                            </div>
                            <div class="single-grid">
                                <img src="<?php echo get_template_directory_uri();?>/assets/images/accessori/c5.png" alt="">
                            </div>
                            <div class="single-grid">
                                <img src="<?php echo get_template_directory_uri();?>/assets/images/accessori/c6.png" alt="">
                            </div>
                            <div class="single-grid">
                                <img src="<?php echo get_template_directory_uri();?>/assets/images/accessori/c7.png" alt="">
                            </div>
                            <div class="single-grid">
                                <img src="<?php echo get_template_directory_uri();?>/assets/images/accessori/c8.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="certificate-title">
                        <h3>Le nostre certificazioni</h3>
                    </div>
                    <div class="certificate-desc">
                        <p>Protek® è il racconto di una storia familiare, di persone determinate e di un forte
                            legame con il territorio.</p>
                        <p>I fratelli Giovanni e Maurizio Maggioni, a metà degli Anni ‘80, raccolgono l’eredità di
                            esperienze e le redini dell’attività artigianale del papà Rino, fondata nel 1951: una
                            piccola officina meccanica, operante nel cuore della Brianza.
                            Intraprendenza e dedizione sono state e sono le caratteristiche che hanno consentito
                            loro di sviluppare negli anni numerosi progetti, rivolti ai più differenti settori
                            dell’industria e dell’artigianato.</p>
                    </div>
                    <div class="certifca-btn">
                        <a href="#">
                            vedi tutte le certificazioni
                            <svg xmlns="http://www.w3.org/2000/svg" width="65" height="8" viewBox="0 0 65 8" fill="none">
                                <path d="M64.5213 4.35355C64.7166 4.15829 64.7166 3.8417 64.5213 3.64644L61.3394 0.464461C61.1441 0.269199 60.8275 0.269199 60.6322 0.464461C60.437 0.659723 60.437 0.976305 60.6322 1.17157L63.4607 3.99999L60.6322 6.82842C60.437 7.02368 60.437 7.34027 60.6322 7.53553C60.8275 7.73079 61.1441 7.73079 61.3394 7.53553L64.5213 4.35355ZM0.234375 4.5L64.1678 4.49999L64.1678 3.49999L0.234375 3.5L0.234375 4.5Z" fill="black" />
                            </svg>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- chisiamo certifacte section ends here  -->

<?php

    $result = ob_get_clean();
    return $result;
}
